package com.isiko.isiko;

import android.media.Image;

/**
 * Created by kaka on 26-Feb-18.
 */

public class Listener {
    protected String id;
    protected String name;
    protected String images;
    protected String description;
    protected String exhibition_comissioner;
    protected String scenographs;
    protected String place;
    protected String artists;
    protected String artMouvement;
    protected String starting_exhibition_date;
    protected String ending_exhibition_date;
    protected String date_dispo_isiko;
    protected String stars;

}
